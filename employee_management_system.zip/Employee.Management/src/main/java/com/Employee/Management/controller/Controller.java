package com.Employee.Management.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Employee.Management.Entity.employee;
import com.Employee.Management.service.Service;

@RestController
@CrossOrigin(origins="http://localhost:4200/")
public class Controller {

	@Autowired
	Service service;
	
	@GetMapping("employees/{Id}")
	public employee getempdata (@PathVariable(value = "Id") int Id) {
		employee employee= service.getempdata(Id);
		return employee;
	}
	
	@GetMapping("employees")
	public List<employee> getAllemployeedata() {
		return service.getAllemployeedata();
	}
	
	@PostMapping("employees")
	public employee saveEmployee (@RequestBody employee Employee) {
		service.saveEmployee(Employee);
		
		  return Employee;
	}
	@PutMapping("employees")
	public employee UpdateEmployee (@RequestBody employee Employee) {
	return service.UpdateEmployee(Employee);
	
	}
	
	@DeleteMapping("employees/{Id}")
	public String DeleteEmployeeById (@PathVariable( value = "Id") int Id) {
		service.DeleteEmployeeById(Id);
		
		return "Delete succesfully";
	}
}
