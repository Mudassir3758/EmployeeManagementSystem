package com.Employee.Management.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.Employee.Management.Entity.employee;
import com.Employee.Management.dao.Dao;

@org.springframework.stereotype.Service
public class Service {

	@Autowired
	Dao dao;
	
	public employee getempdata(int Id) {
        return dao.getempdata(Id);
    
		
	}

	public List<employee> getAllemployeedata() {
		return dao.getAllemployeedata();
		
	}

	public employee saveEmployee(employee Employee) {
		return dao.saveEmployee(Employee);
		
	}

	public employee UpdateEmployee(employee Employee) {
		return dao.UpdateEmployee(Employee);
	}
	
	public String  DeleteEmployeeById(int Id) {
		dao.DeleteEmployeeById(Id);
		return "Delete succesfully";
	}

}
