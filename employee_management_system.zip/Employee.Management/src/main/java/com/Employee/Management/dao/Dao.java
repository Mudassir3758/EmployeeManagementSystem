package com.Employee.Management.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Employee.Management.Entity.employee;


@Repository
public class Dao {

	@Autowired
	SessionFactory sf;
	
	public employee getempdata(int Id) {
		Session session = sf.openSession();
		employee employee = session.get(employee.class , Id);
		return employee;
	}

	public List<employee> getAllemployeedata() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(employee.class);
		List<employee> list = criteria.list();
		return list;
		
	}

	public employee saveEmployee(employee Employee) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.save(Employee);
		tr.commit();
		return Employee;
		
	}

	public employee UpdateEmployee(employee Employee) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.update(Employee);

		tr.commit();
		return Employee;
		
	}
	public String  DeleteEmployeeById(int Id) {
		Session session = sf.openSession();
	 employee empid1 = session.get(employee.class, Id);
	 	Transaction tr = session.beginTransaction();
		session.delete(empid1);
		tr.commit();
		return "Delete succesfully";
}
}
