package com.Employee.Management.Entity;

import javax.persistence.Entity;

import javax.persistence.*;

@Entity
public class employee {
	
 
    
    @Id
    int Id;
	String Firstname;
	String Lastname;
	String Emailid;
	String Address;

	public employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public employee(int id, String firstname, String lastname, String emailid,String address) {
		super();
		Id = id;
		Firstname = firstname;
		Lastname = lastname;
		Emailid = emailid;
		Address = address;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getFirstname() {
		return Firstname;
	}

	public void setFirstname(String firstname) {
		Firstname = firstname;
	}

	public String getLastname() {
		return Lastname;
	}

	public void setLastname(String lastname) {
		Lastname = lastname;
	}

	public String getEmailid() {
		return Emailid;
	}

	public void setEmailid(String emailid) {
		Emailid = emailid;
	}
	

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}



	
	
	
}
